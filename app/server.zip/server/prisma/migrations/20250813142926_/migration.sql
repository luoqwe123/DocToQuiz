-- AlterTable
ALTER TABLE `jsonresults` ADD COLUMN `status` VARCHAR(191) NULL;
