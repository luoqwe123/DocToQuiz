


const fs = require('fs');
const path = require("path");
const pdf = require('pdf-parse');


interface ChunkType {
    chunk: string,
    endPosition: number
}
function processText(text: string, maxChunkSize: number): ChunkType[] {
    let position = 0; // 当前位置
    const result: any = []; // 存储分块结果

    while (position < text.length) {
        // 计算初步结束位置
        let tentativeEnd = position + maxChunkSize;
        if (tentativeEnd > text.length) {
            tentativeEnd = text.length; // 超出文本长度时调整为文本末尾
        }

        // 提取当前分块
        const substring = text.substring(position, tentativeEnd);
        const lastDIndex = substring.lastIndexOf("D."); // 查找最后一个"D."

        let chunkEnd: any;
        if (lastDIndex !== -1) {
            // 找到 "D." 后的起始位置
            let afterD = position + lastDIndex + 2;
            // 在文本中从 afterD 开始查找下一个空格
            let nextSpaceIndex = text.indexOf(' ', afterD);
            if (nextSpaceIndex !== -1) {
                // 如果找到空格，chunkEnd 设置为空格后的位置
                chunkEnd = nextSpaceIndex + 1;
            } else {
                // 如果没有找到空格，使用文本末尾
                chunkEnd = text.length;
            }
        } else {
            // 未找到"D."，使用初步结束位置
            chunkEnd = tentativeEnd;
        }

        // 提取分块内容
        let chunk = text.substring(position, chunkEnd);
        result.push({
            chunk: chunk, // 分块内容
            endPosition: chunkEnd // 结束位置
        });

        // 更新位置为下一次筛选的起点
        position = chunkEnd;
    }

    return result;
}


function processAnswer(text: string, maxChunkSize: number) {
    console.log(text)
    let position = 0; // 当前位置
    const result: any = []; // 存储分块结果
    let flag = false;
    while (position < text.length) {
        // 计算初步结束位置
        console.log(position,text.length)
        let tentativeEnd = position + maxChunkSize;
        if(flag) break;
        if (tentativeEnd > text.length) {
            tentativeEnd = text.length; // 超出文本长度时调整为文本末尾
            flag = true
        }
        // 提取当前分块
        let substring = text.substring(position, tentativeEnd);
        substring = substring.split(' ').filter(item=> item).join(' ')
        console.log(substring)

        console.log(substring.length,substring[substring.length-1])
      
        let i = substring.length;
        if (!flag) {
            i--;
            while (!(/\d/.test(substring[i])&&!/\d/.test(substring[i-1])&&/[a-dA-D]/.test(substring[i-2]))&&i>0) {
                i--;
            }
        }
        // 提取分块内容
        let chunk = substring.substring(0, i);
        console.log(chunk)
        result.push({
            chunk: chunk, // 分块内容
            endPosition: position+i // 结束位置
        });

        // 更新位置为下一次筛选的起点
        position += i;
    }
    return result;
}

function deleteAnswer(textArr: string[]): { answers: string, cleanedText: string } {
    const marker = "参考答案";
    const answerLines: string[] = [];


    answerLines.push(marker);
    //  筛选出答案行（包含数字和选项A/B/C/D且没有中文字符的行）
    let indexs: number[] = [];
    for (let i = 0; i < textArr.length;) {
        const trimmedLine = textArr[i].trim();
        if (/[\d]/.test(trimmedLine) && /[A-D]/.test(trimmedLine) && !/[\u4e00-\u9fa5]/.test(trimmedLine)) {
            answerLines.push(trimmedLine);

            textArr.splice(i, 1)
            continue;
        }
        if (trimmedLine.includes(marker)) {
            textArr.splice(i, 1);
            continue;
        }
        i++;


    }
    if (answerLines.length === 0) {
        throw new Error("参考答案无答案");
    }
    return { answers: answerLines.join(" "), cleanedText: textArr.join(" ") };
}

export async function pdfTostr(buffer: Buffer) {
    // const filePath = path.join(__dirname, '../../public/test.pdf');
    const dataBuffer = buffer;
    const data = await pdf(dataBuffer);
    const text: string[] = data.text.trim().split("\n").filter((item: string) => item.trim().length > 0);
    const { answers, cleanedText } = deleteAnswer(text);
    let endAnswers = processAnswer(answers, 400);
    console.log(endAnswers)
    const endTextArray = processText(cleanedText, 2800);
    
    return { answers:endAnswers, questions: endTextArray };
}
